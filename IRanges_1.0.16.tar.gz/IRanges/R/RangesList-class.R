### =========================================================================
### RangesList objects
### -------------------------------------------------------------------------

## Accepts any type of Ranges instance as an element

setClass("RangesList", prototype = prototype(elementClass = "Ranges"),
         contains = "TypedList")

setClass("IRangesList", prototype = prototype(elementClass = "IRanges"),
         contains = "RangesList")


### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Accessor methods.
###

setMethod("start", "RangesList",
          function(x) unlist(lapply(x, start), use.names = FALSE))
setMethod("end", "RangesList",
          function(x) unlist(lapply(x, end), use.names = FALSE))
setMethod("width", "RangesList",
          function(x) unlist(lapply(x, width), use.names = FALSE))

### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Constructor.
###

RangesList <- function(...)
{
  ranges <- list(...)
  NAMES <- names(ranges)
  names(ranges) <- NULL
  new("RangesList", elements=ranges, NAMES=NAMES)
}

IRangesList <- function(...)
{
    ranges <- list(...)
    NAMES <- names(ranges)
    names(ranges) <- NULL
    new("IRangesList", elements=ranges, NAMES=NAMES)
}

### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Methods that are vectorized over the ranges
###

setMethod("isEmpty", "RangesList",
          function(x)
          {
            if (length(x) == 0)
              return(logical(0))
            sapply(elements(x), isEmpty)
          }
          )

### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Some useful endomorphisms: "reduce" and "gaps".
###

### 'with.inframe.attrib' is ignored.
setMethod("reduce", "RangesList",
          function(x, with.inframe.attrib=FALSE)
          {
            elements <- elements(x)
            if (length(elements) == 0) {
              nir1 <- new("NormalIRanges")
            } else {
              start1 <- start(x)
              width1 <- width(x)
              ranges <- new2("IRanges", start=start1, width=width1, check=FALSE)
              nir1 <- asNormalIRanges(ranges, force=TRUE)
            }
            ## This transformation must be atomic.
            x@elements <- list(nir1)
            x@NAMES <- NULL
            x
          }
          )

setMethod("gaps", "RangesList",
          function(x, start=NA, end=NA)
          {
            names(x) <- NULL
            x@elements <- lapply(x, function(r) gaps(r, start=start, end=end))
            x
          }
          )


### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Coercion.
###

setMethod("as.data.frame", "RangesList",
          function(x, row.names=NULL, optional=FALSE, ...)
          {
            if (!(is.null(row.names) || is.character(row.names)))
              stop("'row.names'  must be NULL or a character vector")
            if (!missing(optional) || length(list(...)))
              warning("'optional' and arguments in '...' ignored")
            x <- as(x, "IRangesList")
            as.data.frame(unlist(x), row.names = row.names)
          })

### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### The "show" method.
###

setMethod("show", "RangesList",
          function(object)
          {
            lo <- length(object)
            cat("  A ", class(object), " instance of length ", lo, "\n", sep="")
            ### TODO: show (some of the) ranges here
          }
          )


### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### The "summary" method.
###

setMethod("summary", "RangesList",
          function(object)
          {
            object <- as(object, "IRangesList")
            if (all(unlist(lapply(object, is, "IRanges"))))
              .Call("summary_IRangesList", object, PACKAGE="IRanges")
            else
              stop("all elements must be of class 'IRanges' ")
          })


### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Coercion.
###

setMethod("as.data.frame", "RangesList",
          function(x, row.names=NULL, optional=FALSE, ...)
          {
            if (!(is.null(row.names) || is.character(row.names)))
              stop("'row.names'  must be NULL or a character vector")
            if (!missing(optional) || length(list(...)))
              warning("'optional' and arguments in '...' ignored")
            x <- as(x, "IRangesList")
            df <- as.data.frame(unlist(x), row.names = row.names)
            if (!is.null(names(x)))
              df <- cbind(space = rep(names(x), unlist(lapply(x, length))), df)
            df
          })

setMethod("unlist", "IRangesList",
          function(x, recursive = TRUE, use.names = TRUE) {
            if (!missing(recursive))
              warning("'recursive' argument currently ignored")
            ans <- callNextMethod()
            if (is.null(ans))
              ans <- IRanges()
            ans
          })

### From an IRangesList object to a NormalIRanges object.
setAs("IRangesList", "NormalIRanges",
      function(from) reduce(from)[[1]]
      )

setAs("RangesList", "IRangesList",
      function(from) {
        ir <- lapply(from, as, "IRanges")
        names(ir) <- NULL
        new("IRangesList", from, elements = ir)
      })


### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Splitting.
###

setMethod("split", "Ranges",
    function(x, f, drop = FALSE, ...)
    {
        do.call("RangesList", callNextMethod())
    }
)

