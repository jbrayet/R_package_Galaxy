###

debug_AEbufs <- function()
    invisible(.Call("debug_AEbufs", PACKAGE="IRanges"))

debug_memcpy_utils <- function()
    invisible(.Call("debug_memcpy_utils", PACKAGE="IRanges"))

debug_IRanges_class <- function()
    invisible(.Call("debug_IRanges_class", PACKAGE="IRanges"))

debug_IRanges_utils <- function()
    invisible(.Call("debug_IRanges_utils", PACKAGE="IRanges"))

debug_SequencePtr_class <- function()
    invisible(.Call("debug_SequencePtr_class", PACKAGE="IRanges"))

debug_RawPtr_utils <- function()
    invisible(.Call("debug_RawPtr_utils", PACKAGE="IRanges"))

debug_IntegerPtr_utils <- function()
    invisible(.Call("debug_IntegerPtr_utils", PACKAGE="IRanges"))

debug_NumericPtr_utils <- function()
    invisible(.Call("debug_NumericPtr_utils", PACKAGE="IRanges"))

debug_XSequence_class <- function()
    invisible(.Call("debug_XSequence_class", PACKAGE="IRanges"))


