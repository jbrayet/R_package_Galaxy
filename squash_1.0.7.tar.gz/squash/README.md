squash
======

An R package providing functions for color-based visualization of multivariate data, i.e. colorgrams or heatmaps

You can see some examples here:
http://www.cbs.dtu.dk/~eklund/squash/


Installation
------------

You can install the latest release from CRAN like this:

	install.packages("squash")


You can install the latest development version from GitHub like this:

	library(devtools)
	install_github("aroneklund/squash")
